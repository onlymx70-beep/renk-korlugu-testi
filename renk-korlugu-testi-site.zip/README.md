# Rəng Görmə Testi

Bu, sarı–mavi (blue-yellow) rəng çalarlarını müqayisə edən sadə, mobil uyğun test saytıdır.

## İstifadə
`index.html` faylını brauzerdə açmaq kifayətdir.

## İnternetdə yayımlamaq
Saytı Google-da axtarış nəticələrində görünən internet saytına çevirmək üçün faylı bir statik hostinq xidmətinə yerləşdirmək lazımdır.
Məsələn, GitHub Pages kimi xidmətlərdən istifadə edib sonra öz domenini qoşa bilərsən.

## Vacib
Bu test tibbi diaqnoz deyil və cihazın ekranı, parlaqlığı, rəng parametrləri nəticəyə təsir edə bilər.
